# DOG Moon Pot

Simple $DOG token lottery app built with Node.js, Express, and basic frontend.

## Quick Start

1. Go to backend folder:
   ```bash
   cd backend
   npm install
   npm start
   ```
2. Open in browser:
   ```
   http://localhost:3000
   ```

Ready to Enter the Pot and Draw Winners!
